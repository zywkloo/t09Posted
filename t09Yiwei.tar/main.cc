#include <iostream>
#include <string>
using namespace std;

#include "Control.h"

int main()
{
  Control control;
  control.launch();

  return 0;
}





